
import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

export default function BookingForm() {
  const [formData, setFormData] = useState({
    name: '',
    info1: '',
    info2: '',
    phone: '',
    email: '',
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log('Gespeichert:', formData);
    alert('Termin gespeichert!');
    setFormData({ name: '', info1: '', info2: '', phone: '', email: '' });
  };

  return (
    <Card className="max-w-md mx-auto mt-10 p-4 shadow-xl">
      <CardContent>
        <h2 className="text-xl font-bold mb-4">Autopilot Termin</h2>
        <form onSubmit={handleSubmit} className="space-y-3">
          <Input name="name" placeholder="Name" value={formData.name} onChange={handleChange} />
          <Input name="info1" placeholder="Fahrzeug / Haartyp / etc." value={formData.info1} onChange={handleChange} />
          <Input name="info2" placeholder="Kennzeichen / Wunsch / etc." value={formData.info2} onChange={handleChange} />
          <Input name="phone" placeholder="Telefonnummer" value={formData.phone} onChange={handleChange} />
          <Input name="email" placeholder="E-Mail" value={formData.email} onChange={handleChange} />
          <Button type="submit" className="w-full">Termin speichern</Button>
        </form>
      </CardContent>
    </Card>
  );
}
