
import React from 'react';

export default function Home() {
  return (
    <main style={{ padding: 40, fontFamily: 'sans-serif' }}>
      <h1>AutoPilot CRM</h1>
      <p>Willkommen bei deinem digitalen Kundenmanager!</p>
    </main>
  );
}
